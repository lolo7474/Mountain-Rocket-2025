package org.firstinspires.ftc.teamcode.vittoz;

/**
 * coordonnee dans le terrain
 */
class Coordonnee
{
    String nom;
    double x_dans_terrain;
    double y_dans_terrain;
    Coordonnee (String nom, double x_dans_terrain, double y_dans_terrain){
        this.nom = nom;
        this.x_dans_terrain = x_dans_terrain;
        this.y_dans_terrain = y_dans_terrain;
    }

    /**
     * Affichage des coordonnées
     * @return
     */
    public String toString() {
        return nom+"{" + ""+
                "x=" + String.format("%.2f", x_dans_terrain) + ""+
                "y=" + String.format("%.2f", y_dans_terrain) + ""+
                '}';
    }
}
